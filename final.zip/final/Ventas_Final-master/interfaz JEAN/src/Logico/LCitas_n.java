/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logico;

import Datos.DCitas;
import Datos.DVentas;
import ventanas.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author MASTER
 */
public class LCitas_n {
    //Creacion de la conexion y la variable de la misma
    private Conexion mysql=new Conexion();
    private Connection cn=mysql.Conectar();
    private String sSQL="";
    DCitas d=new DCitas();
    
    //Creacion de la tabla de la interfaz
    public DefaultTableModel CargarTabla(){
        DefaultTableModel modelo;
        
        String [] título={"COD Horario","Nom pac","Ape pac","Telefono","Hora Cita", "Fecha Cita"};//Para que se cambie en la columna de las tablas
        String [] registro=new String [6];
       
        
        modelo = new DefaultTableModel(null,título);
        sSQL="select h.COD_HORARIO, p.NOM_PACI_NUEVO, p.APE_PACI_NUEVO, p.TELEFONO_PACI, h.HORA_CITA, h.FECHA_CITA from HORARIO h, CITA_MEDICA c, PACIENTE_NUEVO p"+
        " where h.COD_HORARIO=c.COD_HORARIO and c.COD_PACIENTE=p.COD_PACIENTE";              
                 
        try {
            Statement st=cn.createStatement();
            ResultSet rs=st.executeQuery(sSQL);
            
            
            while(rs.next()){
                registro[0]=rs.getString("COD_HORARIO");
                registro[1]=rs.getString("NOM_PACI_NUEVO");
                registro[2]=rs.getString("APE_PACI_NUEVO");
                registro[3]=rs.getString("TELEFONO_PACI");
                registro[4]=rs.getString("HORA_CITA");
                registro[5]=rs.getString("FECHA_CITA");
               modelo.addRow(registro);
                
            }
            return modelo;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
    public DefaultTableModel buscarporfecha(String fecha,String fecha1){
        DefaultTableModel modelo;
        
        String [] título={"COD Horario","Nom pac","Ape pac","Telefono","Hora Cita", "Fecha Cita"};//Para que se cambie en la columna de las tablas
        String [] registro=new String [6];
        
        modelo = new DefaultTableModel(null,título);
        sSQL="select h.COD_HORARIO, p.NOM_PACI_NUEVO, p.APE_PACI_NUEVO, p.TELEFONO_PACI, h.HORA_CITA, h.FECHA_CITA from HORARIO h, CITA_MEDICA c, PACIENTE_NUEVO p"+
        " where h.COD_HORARIO=c.COD_HORARIO and c.COD_PACIENTE=p.COD_PACIENTE and h.FECHA_CITA>='"+fecha+"'"+" and h.FECHA_CITA<='"+fecha1+"'";
             
        try {
            Statement st=cn.createStatement();
            ResultSet rs=st.executeQuery(sSQL);
            
            while(rs.next()){
                registro[0]=rs.getString("COD_HORARIO");
                registro[1]=rs.getString("NOM_PACI_NUEVO");
                registro[2]=rs.getString("APE_PACI_NUEVO");
                registro[3]=rs.getString("TELEFONO_PACI");
                registro[4]=rs.getString("HORA_CITA");
                registro[5]=rs.getString("FECHA_CITA");
               
                modelo.addRow(registro);
                
            }
            return modelo;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
     public DefaultTableModel buscarpornombre(String busca){
        DefaultTableModel modelo;
        
        String [] título={"COD Horario","Nom pac","Ape pac","Telefono","Hora Cita", "Fecha Cita"};//Para que se cambie en la columna de las tablas
        String [] registro=new String [6];
        
        modelo = new DefaultTableModel(null,título);
        
         sSQL="select h.COD_HORARIO, p.NOM_PACI_NUEVO, p.APE_PACI_NUEVO, p.TELEFONO_PACI, h.HORA_CITA, h.FECHA_CITA from HORARIO h, CITA_MEDICA c, PACIENTE_NUEVO p"+
        " where h.COD_HORARIO=c.COD_HORARIO and c.COD_PACIENTE=p.COD_PACIENTE and p.NOM_PACI_NUEVO='"+busca+"'";
              
        try {
            Statement st=cn.createStatement();
            ResultSet rs=st.executeQuery(sSQL);
            
            while(rs.next()){
                registro[0]=rs.getString("COD_HORARIO");
                registro[1]=rs.getString("NOM_PACI_NUEVO");
                registro[2]=rs.getString("APE_PACI_NUEVO");
                registro[3]=rs.getString("TELEFONO_PACI");
                registro[4]=rs.getString("HORA_CITA");
                registro[5]=rs.getString("FECHA_CITA");
                modelo.addRow(registro);
                
            }
            return modelo;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
     public DefaultTableModel buscarcompleto(String busca, String fecha, String fecha1){
        DefaultTableModel modelo;
        
        String [] título={"COD Horario","Nom pac","Ape pac","Telefono","Hora Cita", "Fecha Cita"};//Para que se cambie en la columna de las tablas
        String [] registro=new String [6];
        
        modelo = new DefaultTableModel(null,título);
        
         sSQL="select h.COD_HORARIO, p.NOM_PACI_NUEVO, p.APE_PACI_NUEVO, p.TELEFONO_PACI, h.HORA_CITA, h.FECHA_CITA from HORARIO h, CITA_MEDICA c, PACIENTE_NUEVO p"+
        " where h.COD_HORARIO=c.COD_HORARIO and c.COD_PACIENTE=p.COD_PACIENTE and p.NOM_PACI_NUEVO='"+busca+"'"+" and h.FECHA_CITA>='"+fecha+"'"+" and h.FECHA_CITA<='"+fecha1+"'";
              
        try {
            Statement st=cn.createStatement();
            ResultSet rs=st.executeQuery(sSQL);
            
            while(rs.next()){
                registro[0]=rs.getString("COD_HORARIO");
                registro[1]=rs.getString("NOM_PACI_NUEVO");
                registro[2]=rs.getString("APE_PACI_NUEVO");
                registro[3]=rs.getString("TELEFONO_PACI");
                registro[4]=rs.getString("HORA_CITA");
                registro[5]=rs.getString("FECHA_CITA");
                modelo.addRow(registro);
                
            }
            return modelo;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
      
    public boolean editarHorario (DCitas dci){
        sSQL="update HORARIO set HORA_CITA=?, FECHA_CITA=? where COD_HORARIO=?";
       try {
            PreparedStatement pst=cn.prepareStatement(sSQL);
            
            pst.setString(1, dci.getHoraCita());
            pst.setString(2, dci.getFechaCita());
            pst.setInt(3, dci.getCOD_Horario());
                                
            int n=pst.executeUpdate();
            if(n!=0){
                return true;//Si se inserto los registros
            }else{
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return false;//Si no se conecto a la base
        }
        
     
    }
       
}