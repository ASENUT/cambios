/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logico;

import Datos.DVentas;
import ventanas.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;

/**
 *
 * @author MASTER
 */
public class LVentas {
    DVentas v=new DVentas();
    private Conexion mysql=new Conexion();
    private Connection cn=mysql.Conectar();
    private String sSQL="";
    private String sSQL2="";
    static String codigo;
    
    public void Mostrar(String Cedula, DVentas v, String Codigo){
        sSQL="select distinct NOM_PAC, APE_PAC, TELF_CONVEN, TELF_MOVIL, COSTO_TOTAL, ABONO_MULTA, SALDO, TIPO_PAGO, COD_FICHA" +
" from PACIENTE p, FICHA_ECONOMICA f, TIPO_DE_PAGO t where p.CEDULA="+Cedula+" and f.CEDULA="+Cedula+
" and f.COD_TRATAMIENTO="+Codigo+ " or f.COD_TIPO_PAGO=t.TIPO_PAGO group by COD_FICHA ";
        try {
            Statement st=cn.createStatement();
            ResultSet rs=st.executeQuery(sSQL);
            
            while (rs.next()){
                v.setNombre(rs.getString("NOM_PAC"));
                v.setApellido(rs.getString("APE_PAC"));
                v.setTelefonoC(rs.getString("TELF_CONVEN"));
                v.setTelefonoM(rs.getString("TELF_MOVIL"));
                v.setCosto(rs.getString("COSTO_TOTAL"));
                v.setAbono(rs.getString("ABONO_MULTA"));
                v.setSaldo(rs.getString("SALDO"));
                codigo=rs.getString("COD_FICHA");
                v.setCodigo(codigo);
                v.setTipo_Pago(rs.getString("TIPO_PAGO"));
            }
                
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public boolean Cobrar (String Total, DVentas v){
        String Stock=v.getProductos();
        String Tipo_Trata=v.getTipo_Tratamiento();
        String NumeroProducto=v.getNumero_Producto();
        sSQL="update FICHA_ECONOMICA set SALDO="+Total+ " where COD_FICHA="+codigo+" and COD_TRATAMIENTO=(select COD_TRATAMIENTO from " +
        "TIPO_TRATAMIENTO where NOM_TRATA='"+Tipo_Trata+"')";
        sSQL2="update PRODUCTOS set STOCK=STOCK-"+NumeroProducto+" where COD_PRODUCTO="+Stock;
            try {
            PreparedStatement pst=cn.prepareStatement(sSQL);
            int n=pst.executeUpdate();
            PreparedStatement pt=cn.prepareStatement(sSQL2);
            int h=pt.executeUpdate();
            if(n!=0 && h!=0){
                return true;//Si se inserto los registros
            }else{
                return false;
            }
        } catch (Exception e) {
            return false;
        }
    }
  
}
